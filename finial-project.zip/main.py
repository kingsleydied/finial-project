print("Hello! This is a nutrition bot!")

# Function to calculate remaining calories
def calculate_remaining_calories(daily_calorie_intake, calories_consumed):
    remaining_calories = daily_calorie_intake - calories_consumed
    if remaining_calories > 0:
        print(f"You can still eat {remaining_calories} calories today!")
    else:
        print("You have reached or exceeded your daily calorie limit.")

# Main part of the program
gender = input("Are you male or female?: ")

# Male part
if gender.lower() == "male":
    print("Great!")

    # Activity for males
    activity = input("What is your activity level: very active, somewhat, or low? ")

    if activity.lower() == "very active":
        print("It's healthy to be active!")
    elif activity.lower() == "somewhat":
        print("Nice!")
    elif activity.lower() == "low":
        print("It's good to relax.")
    else:
        print("Input only activity levels please.")

    # Height for males
    height = input("Lastly, what is your height? Above 6'0, 5'7-5'11, or below 5'7: ")

    if height.lower() == "above 6'0":
        daily_calorie_intake = 2800
        print("For someone of your activity level and height, you should consume 2,600 to 3,000 calories!")
    elif height.lower() == "5'7-5'11":
        daily_calorie_intake = 2600
        print("For your activity level and height, you should consume 2,400 to 2,800 calories.")
    elif height.lower() == "below 5'7":
        daily_calorie_intake = 2400
        print("You should consume 2,200 to 2,600 calories in a day!")
    else:
        print("Height not recognized.")
        daily_calorie_intake = 0

# Female part
elif gender.lower() == "female":
    print("Great!")

    # Activity for females
    activity = input("What is your activity level: very active, somewhat, or low? ")

    if activity.lower() == "very active":
        print("It's healthy to be active!")
    elif activity.lower() == "somewhat":
        print("Nice!")
    elif activity.lower() == "low":
        print("It's good to relax.")
    else:
        print("Input only activity levels please.")

    # Height for females
    height = input("Lastly, what is your height? Above 5'8, 5'3-5'6, or 4'11-5'2: ")

    if height.lower() == "above 5'8":
        daily_calorie_intake = 2200
        print("For someone of your activity level and height, you should consume 2,200 calories!")
    elif height.lower() == "5'3-5'6":
        daily_calorie_intake = 2000
        print("For your activity level and height, you should consume 2,000 calories.")
    elif height.lower() == "4'11-5'2":
        daily_calorie_intake = 1600
        print("You should consume 1,600 calories in a day!")
    else:
        print("Height not recognized.")
        daily_calorie_intake = 0
else:
    print("Please enter either 'male' or 'female' as your gender.")
    daily_calorie_intake = 0

# To calulate how many more calorires you can eat
if daily_calorie_intake > 0:
    try:
        calories_consumed = float(input("Enter the calories you've consumed so far today: "))
        calculate_remaining_calories(daily_calorie_intake, calories_consumed)
    except ValueError:
        print("Please enter a valid number for calories consumed.")
